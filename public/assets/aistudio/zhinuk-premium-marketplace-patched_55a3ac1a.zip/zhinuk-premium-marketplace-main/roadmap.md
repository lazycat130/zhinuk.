# Zhinuk requested upgrades

- [x] Verify original demo catalog and logo before other changes: eight original fixtures present, logo loaded, no broken homepage images; disappearance not reproduced.
- [ ] Preserve homepage and update confirmed contact links.
- [ ] Implement compact product details and real order submission.
- [ ] Enable persistent products, images, admin access and server-enforced permissions.
- [ ] Implement product, order and customer management.
- [ ] Integrate consent-aware Meta Pixel when the actual ID is supplied.
- [ ] Verify management, order persistence, privacy and desktop/mobile flows; report limitations.