import { Link } from "@tanstack/react-router";
import { useState, type ReactElement } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import logo from "@/assets/zhinuk-logo.png.asset.json";
import { categories } from "@/lib/catalog";
import { navLinks } from "./Header";

export function MobileNavigation({ trigger }: { trigger: ReactElement }) {
  const [open, setOpen] = useState(false);
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent side="left" className="w-[86vw] max-w-sm overflow-y-auto p-0">
        <SheetHeader className="border-b border-border p-4">
          <SheetTitle><img src={logo.url} alt="ঝিনুক" className="h-14 mix-blend-multiply" /></SheetTitle>
        </SheetHeader>
        <ul className="p-2">
          {navLinks.map((l) => (
            <li key={l.label}>
              <Link to={l.to} search={("search" in l ? l.search : {}) as never} onClick={() => setOpen(false)} className="block rounded-lg px-4 py-3 font-medium hover:bg-muted">
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
        <p className="px-6 pt-2 text-xs font-semibold text-muted-foreground">ক্যাটাগরি</p>
        <div className="grid grid-cols-4 gap-3 p-4">
          {categories.map((c) => (
            <Link key={c.slug} to="/shop" search={{ cat: c.slug }} onClick={() => setOpen(false)} className="flex flex-col items-center gap-1 text-center text-xs">
              <img src={c.image} alt="" className="h-14 w-14 rounded-full border border-border bg-card object-contain p-1.5" />
              {c.name}
            </Link>
          ))}
        </div>
      </SheetContent>
    </Sheet>
  );
}
