import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Mail, MapPin, Phone, Youtube, Lock, Truck, Headphones } from "lucide-react";
import logo from "@/assets/zhinuk-logo.png.asset.json";

export function Footer() {
  return (
    <footer className="mt-14">
      <div className="mx-auto max-w-[1440px] px-4 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-4 rounded-t-3xl border border-b-0 border-border bg-card/80 px-6 py-4 sm:grid-cols-2 lg:grid-cols-5">
          <img src={logo.url} alt="ঝিনুক" className="h-20 mix-blend-multiply" />
          {[
            { Icon: Lock, t: "নিরাপদ পেমেন্ট", d: "১০০% নিরাপদ লেনদেন" },
            { Icon: Truck, t: "দ্রুত ডেলিভারি", d: "সারা বাংলাদেশে" },
            { Icon: Headphones, t: "সাপোর্ট", d: "২৪/৭ কাস্টমার সাপোর্ট" },
          ].map(({ Icon, t, d }) => (
            <div key={t} className="flex items-center gap-3">
              <Icon className="h-8 w-8 text-navy" strokeWidth={1.5} />
              <div className="text-sm"><p className="font-medium text-navy">{t}</p><p className="text-muted-foreground">{d}</p></div>
            </div>
          ))}
          <p className="-rotate-6 font-script text-2xl text-navy">ঝিনুক<br /><span className="pl-4 text-xl">থাকুক আপনার পাশে</span></p>
        </div>
      </div>
      <div className="bg-navy text-navy-foreground">
        <div className="mx-auto grid max-w-[1440px] gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4 lg:px-8">
          <div>
            <p className="text-2xl font-bold tracking-wide">ZHINUK <span className="font-script font-normal">ঝিনুক</span></p>
            <p className="mt-3 text-sm leading-relaxed text-navy-foreground/75">ঝিনুক একটি প্রিমিয়াম বাংলাদেশি অনলাইন শপ — ফ্যাশন, বিউটি, ইলেকট্রনিক্স ও লাইফস্টাইলের বাছাই করা অরিজিনাল পণ্য, আপনার দোরগোড়ায়।</p>
            <div className="mt-4 flex gap-3">
              {[Facebook, Instagram, Youtube].map((I, i) => (
                <a key={i} href="#" aria-label="সোশ্যাল মিডিয়া" className="grid h-9 w-9 place-items-center rounded-full bg-navy-foreground/10 transition hover:bg-highlight"><I className="h-4 w-4" /></a>
              ))}
            </div>
          </div>
          <FooterCol title="দ্রুত লিংক" links={[["হোম", "/"], ["আমাদের সম্পর্কে", "/about"], ["যোগাযোগ", "/contact"], ["শপ", "/shop"]]} />
          <FooterCol title="কাস্টমার সার্ভিস" links={[["সাহায্য কেন্দ্র", "/contact"], ["অর্ডার ট্র্যাকিং", "/track"], ["রিটার্ন পলিসি", "/about"], ["ডেলিভারি তথ্য", "/about"]]} />
          <div>
            <h4 className="mb-4 font-semibold">যোগাযোগ</h4>
            <ul className="space-y-3 text-sm text-navy-foreground/75">
              <li className="flex gap-2"><Phone className="h-4 w-4 shrink-0" /> +৮৮০ ১৭০০-০০০০০০</li>
              <li className="flex gap-2"><Mail className="h-4 w-4 shrink-0" /> support@zhinuk.com</li>
              <li className="flex gap-2"><MapPin className="h-4 w-4 shrink-0" /> গুলশান-২, ঢাকা ১২১২, বাংলাদেশ</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-navy-foreground/10 py-4 text-center text-xs text-navy-foreground/60">© ২০২৬ ZHINUK. সর্বস্বত্ব সংরক্ষিত।</div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: [string, "/" | "/about" | "/contact" | "/shop" | "/track"][] }) {
  return (
    <div>
      <h4 className="mb-4 font-semibold">{title}</h4>
      <ul className="space-y-2.5 text-sm text-navy-foreground/75">
        {links.map(([l, to]) => <li key={l}><Link to={to} className="transition hover:text-navy-foreground hover:underline">{l}</Link></li>)}
      </ul>
    </div>
  );
}
