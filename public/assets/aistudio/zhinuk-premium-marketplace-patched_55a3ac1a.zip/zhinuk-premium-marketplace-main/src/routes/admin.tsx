import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { formatPrice } from "@/lib/catalog";
import { toast } from "sonner";
import { Archive, Boxes, LogOut, PackagePlus, RefreshCw, ShieldCheck, ShoppingBag, Users } from "lucide-react";

export const Route = createFileRoute("/admin")({ component: AdminPage });
type ProductRow = { id: string; name: string; name_en: string | null; sku: string | null; category: string; price: number; regular_price: number | null; image_url: string; description: string; stock_quantity: number; status: "draft" | "published" | "archived"; is_demo: boolean };
type OrderRow = { id: string; order_number: string; status: string; payment_status: string; total: number; created_at: string; customers?: { full_name: string; phone_normalized: string } | null };
type CustomerRow = { id: string; full_name: string; phone_normalized: string; email: string | null; address: string; district: string; created_at: string };
const inputClass = "w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary";
const btnClass = "inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground disabled:opacity-50";

function AdminPage() {
  const [session, setSession] = useState<any>(null);
  const [checking, setChecking] = useState(true);
  const [tab, setTab] = useState<"products" | "orders" | "customers">("products");
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [customers, setCustomers] = useState<CustomerRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<ProductRow | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ id: "", name: "", name_en: "", sku: "", category: "lifestyle", price: "", regular_price: "", image_url: "", description: "", stock_quantity: "0", status: "draft" as "draft" | "published" | "archived" });
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const imagePreviewUrl = useMemo(() => imageFile ? URL.createObjectURL(imageFile) : form.image_url, [imageFile, form.image_url]);
  useEffect(() => () => { if (imagePreviewUrl.startsWith("blob:")) URL.revokeObjectURL(imagePreviewUrl); }, [imagePreviewUrl]);

  useEffect(() => {
    let alive = true;
    supabase.auth.getSession().then(({ data }) => { if (alive) { setSession(data.session); setChecking(false); } }).catch(() => { if (alive) setChecking(false); });
    const { data } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => { alive = false; data.subscription.unsubscribe(); };
  }, []);

  const isAdmin = session?.user?.app_metadata?.role === "admin";
  const loadData = useCallback(async () => {
    if (!isAdmin) return;
    setLoading(true);
    try {
      const client = supabase as any;
      const [p, o, c] = await Promise.all([
        client.from("products").select("id,name,name_en,sku,category,price,regular_price,image_url,description,stock_quantity,status,is_demo").order("created_at", { ascending: false }),
        client.from("orders").select("id,order_number,status,payment_status,total,created_at,customers(full_name,phone_normalized)").order("created_at", { ascending: false }).limit(300),
        client.from("customers").select("id,full_name,phone_normalized,email,address,district,created_at").order("created_at", { ascending: false }).limit(1000),
      ]);
      if (p.error) throw p.error; if (o.error) throw o.error; if (c.error) throw c.error;
      setProducts(p.data || []); setOrders(o.data || []); setCustomers(c.data || []);
    } catch (error: any) { toast.error("ডেটা লোড করা যায়নি", { description: error?.message || "Supabase migration ও admin permissions যাচাই করুন।" }); }
    finally { setLoading(false); }
  }, [isAdmin]);
  useEffect(() => { void loadData(); }, [loadData]);

  const resetForm = () => { setEditing(null); setShowForm(false); setImageFile(null); setForm({ id: "", name: "", name_en: "", sku: "", category: "lifestyle", price: "", regular_price: "", image_url: "", description: "", stock_quantity: "0", status: "draft" }); };
  const startEdit = (p: ProductRow) => { setImageFile(null); setEditing(p); setForm({ id: p.id, name: p.name, name_en: p.name_en || "", sku: p.sku || "", category: p.category, price: String(p.price), regular_price: p.regular_price == null ? "" : String(p.regular_price), image_url: p.image_url, description: p.description, stock_quantity: String(p.stock_quantity), status: p.status }); setShowForm(true); };
  const saveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const price = Number(form.price), regular = form.regular_price ? Number(form.regular_price) : null, stock = Number(form.stock_quantity);
    if (!form.name.trim() || !Number.isFinite(price) || price < 0 || (regular !== null && (!Number.isFinite(regular) || regular < price)) || !Number.isInteger(stock) || stock < 0) { toast.error("পণ্যের তথ্য সঠিকভাবে দিন"); return; }
    const id = (form.id.trim() || form.sku.trim() || crypto.randomUUID()).toLowerCase().replace(/[^a-z0-9-]+/g, "-");
    let imageUrl = form.image_url.trim();
    const client = supabase as any;
    if (imageFile) {
      if (!/^image\/(jpeg|png|webp)$/.test(imageFile.type) || imageFile.size > 5 * 1024 * 1024) {
        toast.error("ছবি JPG, PNG বা WebP হতে হবে এবং ৫ MB-এর মধ্যে হতে হবে"); return;
      }
      const extension = imageFile.type === "image/jpeg" ? "jpg" : imageFile.type.split("/")[1];
      const path = `${crypto.randomUUID()}.${extension}`;
      const { error: uploadError } = await client.storage.from("zhinuk-products").upload(path, imageFile, { upsert: false, contentType: imageFile.type });
      if (uploadError) { toast.error("ছবি আপলোড হয়নি", { description: uploadError.message }); return; }
      imageUrl = client.storage.from("zhinuk-products").getPublicUrl(path).data.publicUrl;
    }
    const payload = { id, name: form.name.trim(), name_en: form.name_en.trim() || null, sku: form.sku.trim() || null, category: form.category, price, regular_price: regular, image_url: imageUrl, description: form.description.trim(), stock_quantity: stock, status: form.status, is_demo: editing?.is_demo ?? false };
    const { error } = editing ? await client.from("products").update(payload).eq("id", editing.id) : await client.from("products").insert(payload);
    if (error) { toast.error("সংরক্ষণ হয়নি", { description: error.message }); return; }
    toast.success(editing ? "পণ্য আপডেট হয়েছে" : "পণ্য যোগ হয়েছে"); resetForm(); await loadData();
  };
  const updateProduct = async (p: ProductRow, changes: Partial<ProductRow>) => {
    const { error } = await (supabase as any).from("products").update(changes).eq("id", p.id);
    if (error) toast.error("পরিবর্তন করা যায়নি", { description: error.message }); else { toast.success("পণ্যের অবস্থা আপডেট হয়েছে"); await loadData(); }
  };
  const archiveProduct = async (p: ProductRow) => { if (!window.confirm(`“${p.name}” আর্কাইভ করবেন? অর্ডারের ইতিহাস অক্ষত থাকবে।`)) return; await updateProduct(p, { status: "archived" }); };
  const deleteProduct = async (p: ProductRow) => { if (!window.confirm(`“${p.name}” স্থায়ীভাবে মুছতে চান? পণ্যটির অর্ডার থাকলে database restriction মুছতে বাধা দিতে পারে।`)) return; const { error } = await (supabase as any).from("products").delete().eq("id", p.id); if (error) toast.error("পণ্য মুছতে পারেনি", { description: error.message }); else { toast.success("পণ্য মুছে ফেলা হয়েছে"); await loadData(); } };
  const changeOrderStatus = async (o: OrderRow, status: string) => { const { error } = await (supabase as any).from("orders").update({ status, updated_at: new Date().toISOString() }).eq("id", o.id); if (error) toast.error("অর্ডার আপডেট হয়নি", { description: error.message }); else { toast.success("অর্ডার স্ট্যাটাস আপডেট হয়েছে"); await loadData(); } };
  const filteredProducts = useMemo(() => products.filter(p => `${p.name} ${p.id} ${p.sku || ""}`.toLowerCase().includes(search.toLowerCase())), [products, search]);
  const filteredOrders = useMemo(() => orders.filter(o => `${o.order_number} ${o.customers?.full_name || ""} ${o.customers?.phone_normalized || ""}`.toLowerCase().includes(search.toLowerCase())), [orders, search]);
  const filteredCustomers = useMemo(() => customers.filter(c => `${c.full_name} ${c.phone_normalized} ${c.email || ""}`.toLowerCase().includes(search.toLowerCase())), [customers, search]);
  const exportCustomersCsv = () => {
    if (!isAdmin) { toast.error("এই কাজের অনুমতি নেই"); return; }
    const escape = (value: unknown) => { const raw = String(value ?? ""); const safe = /^[=+@\-\t\r]/.test(raw) ? `'${raw}` : raw; return `"${safe.replace(/"/g, '""')}"`; };
    const rows = [["Name", "Phone", "Email", "Address", "Area", "District", "Created at"], ...filteredCustomers.map(c => [c.full_name, c.phone_normalized, c.email, c.address, c.area, c.district, c.created_at])];
    const csv = "\uFEFF" + rows.map(row => row.map(escape).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8;" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "zhinuk-customers.csv"; anchor.click(); URL.revokeObjectURL(url);
  };

  if (checking) return <div className="mx-auto max-w-5xl px-4 py-20 text-center">অ্যাডমিন অ্যাক্সেস যাচাই হচ্ছে…</div>;
  if (!session || !isAdmin) return <div className="mx-auto max-w-md px-4 py-12"><div className="rounded-3xl border bg-card p-6 shadow-card"><ShieldCheck className="mb-3 h-9 w-9 text-primary"/><h1 className="text-2xl font-bold text-navy">Zhinuk Admin</h1><p className="mb-5 mt-2 text-sm text-muted-foreground">শুধু অনুমোদিত administrator প্রবেশ করতে পারবেন। সাধারণ account-এর metadata-তে admin role থাকলেই হবে না—এটি Supabase app_metadata-তে server-side সেট করতে হবে।</p><form className="space-y-3" onSubmit={async e => { e.preventDefault(); const { error } = await supabase.auth.signInWithPassword({ email, password }); if (error) toast.error("লগইন হয়নি", { description: error.message }); }}><input className={inputClass} type="email" autoComplete="username" required placeholder="Admin email" value={email} onChange={e => setEmail(e.target.value)}/><input className={inputClass} type="password" autoComplete="current-password" required placeholder="Password" value={password} onChange={e => setPassword(e.target.value)}/><button className={`${btnClass} w-full`} type="submit">নিরাপদে লগইন</button></form><p className="mt-4 text-xs text-muted-foreground">Business contact email-কে admin login হিসেবে ধরে নেওয়া হয়নি।</p></div></div>;

  return <div className="mx-auto max-w-7xl px-4 py-8"><div className="mb-6 flex flex-wrap items-center justify-between gap-3"><div><p className="text-sm font-semibold text-primary">ZHINUK COMMERCE HUB</p><h1 className="text-3xl font-bold text-navy">Admin Dashboard</h1><p className="mt-1 text-sm text-muted-foreground">পণ্য, অর্ডার ও কাস্টমার ব্যবস্থাপনা</p></div><div className="flex gap-2"><button className="rounded-xl border px-3 py-2 text-sm" onClick={() => void loadData()}><RefreshCw className="mr-2 inline h-4 w-4"/>Refresh</button><button className="rounded-xl border px-3 py-2 text-sm" onClick={async () => { await supabase.auth.signOut(); setSession(null); }}><LogOut className="mr-2 inline h-4 w-4"/>Logout</button></div></div>
    <div className="mb-5 grid gap-3 sm:grid-cols-3"><div className="rounded-2xl border bg-card p-4"><Boxes className="mb-2 h-5 w-5 text-primary"/><p className="text-sm text-muted-foreground">মোট পণ্য</p><p className="text-2xl font-bold">{products.length}</p></div><div className="rounded-2xl border bg-card p-4"><ShoppingBag className="mb-2 h-5 w-5 text-primary"/><p className="text-sm text-muted-foreground">মোট অর্ডার</p><p className="text-2xl font-bold">{orders.length}</p></div><div className="rounded-2xl border bg-card p-4"><Users className="mb-2 h-5 w-5 text-primary"/><p className="text-sm text-muted-foreground">কাস্টমার</p><p className="text-2xl font-bold">{customers.length}</p></div></div>
    <div className="mb-4 flex flex-wrap gap-2">{([ ["products","পণ্য",Boxes], ["orders","অর্ডার",ShoppingBag], ["customers","কাস্টমার",Users] ] as const).map(([key,label,Icon]) => <button key={key} onClick={() => { setTab(key); setSearch(""); }} className={`rounded-xl px-4 py-2.5 text-sm font-semibold ${tab===key ? "bg-primary text-primary-foreground" : "border bg-card"}`}><Icon className="mr-2 inline h-4 w-4"/>{label}</button>)}</div>
    <div className="mb-4 flex flex-wrap gap-2"><input className={`${inputClass} max-w-lg flex-1`} placeholder="নাম, SKU, অর্ডার নম্বর বা ফোন দিয়ে খুঁজুন" value={search} onChange={e => setSearch(e.target.value)}/>{tab === "products" && <button className={btnClass} onClick={() => { resetForm(); setShowForm(true); }}><PackagePlus className="h-4 w-4"/>নতুন পণ্য</button>}{tab === "customers" && <button className={btnClass} onClick={exportCustomersCsv}>কাস্টমার CSV Export</button>}</div>
    {showForm && tab === "products" && <form onSubmit={saveProduct} className="mb-6 grid gap-3 rounded-2xl border bg-card p-4 sm:grid-cols-2 lg:grid-cols-3"><h2 className="text-lg font-bold sm:col-span-2 lg:col-span-3">{editing ? "পণ্য সম্পাদনা" : "নতুন পণ্য যোগ করুন"}</h2><input className={inputClass} placeholder="পণ্যের নাম (বাংলা)" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/><input className={inputClass} placeholder="English name" value={form.name_en} onChange={e=>setForm({...form,name_en:e.target.value})}/><input className={inputClass} placeholder="Unique SKU" value={form.sku} onChange={e=>setForm({...form,sku:e.target.value})}/><select className={inputClass} value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{["fashion","electronics","beauty","watch","bag","shoes","gadget","lifestyle"].map(x=><option key={x} value={x}>{x}</option>)}</select><input className={inputClass} type="number" min="0" step="0.01" placeholder="বিক্রয়মূল্য (BDT)" required value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/><input className={inputClass} type="number" min={form.price || 0} step="0.01" placeholder="আগের দাম (ঐচ্ছিক)" value={form.regular_price} onChange={e=>setForm({...form,regular_price:e.target.value})}/><input className={inputClass} type="number" min="0" step="1" placeholder="স্টক" required value={form.stock_quantity} onChange={e=>setForm({...form,stock_quantity:e.target.value})}/><div className="space-y-2"><input className={inputClass} placeholder="Image URL (ঐচ্ছিক)" value={form.image_url} onChange={e=>setForm({...form,image_url:e.target.value})}/><input className={inputClass} type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>setImageFile(e.target.files?.[0] || null)}/><p className="text-xs text-muted-foreground">কম্পিউটার থেকে JPG/PNG/WebP, সর্বোচ্চ ৫ MB</p>{imagePreviewUrl && <img className="h-20 w-20 rounded-lg border object-cover" alt="Product preview" src={imagePreviewUrl}/>}</div><select className={inputClass} value={form.status} onChange={e=>setForm({...form,status:e.target.value as any})}><option value="draft">Draft</option><option value="published">Published</option><option value="archived">Archived</option></select><textarea className={`${inputClass} sm:col-span-2 lg:col-span-3`} placeholder="সংক্ষিপ্ত বিবরণ" rows={3} value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/><div className="flex gap-2 sm:col-span-2 lg:col-span-3"><button className={btnClass} type="submit">সংরক্ষণ করুন</button><button type="button" className="rounded-xl border px-4 py-2 text-sm" onClick={resetForm}>বাতিল</button></div></form>}
    {loading ? <div className="rounded-2xl border bg-card p-8 text-center">ডেটা লোড হচ্ছে…</div> : <div className="overflow-x-auto rounded-2xl border bg-card"><table className="w-full min-w-[760px] text-left text-sm"><thead className="bg-ocean-soft text-navy"><tr>{(tab==="products"?["পণ্য","SKU / ID","দাম","স্টক","অবস্থা","কাজ"]:tab==="orders"?["অর্ডার","কাস্টমার","মোট","তারিখ","স্ট্যাটাস","আপডেট"]:["কাস্টমার","ফোন","ইমেইল","ঠিকানা","যোগদানের তারিখ"]).map(x=><th key={x} className="px-4 py-3 font-semibold">{x}</th>)}</tr></thead><tbody className="divide-y">{tab==="products" && filteredProducts.map(p=><tr key={p.id}><td className="px-4 py-3"><div className="flex items-center gap-3">{p.image_url && <img src={p.image_url} alt="" className="h-12 w-12 rounded-lg object-cover"/>}<div><p className="font-semibold">{p.name}</p>{p.is_demo&&<span className="text-xs text-muted-foreground">Demo catalog</span>}</div></div></td><td className="px-4 py-3">{p.sku||p.id}</td><td className="px-4 py-3">{formatPrice(Number(p.price))}</td><td className="px-4 py-3">{p.stock_quantity}</td><td className="px-4 py-3">{p.status}</td><td className="px-4 py-3"><div className="flex flex-wrap gap-2"><button className="rounded-lg border px-2 py-1" onClick={()=>startEdit(p)}>Edit</button>{p.status!=="published"&&<button className="rounded-lg border px-2 py-1" onClick={()=>void updateProduct(p,{status:"published"})}>Publish</button>}<button className="rounded-lg border px-2 py-1" onClick={()=>void archiveProduct(p)}><Archive className="inline h-3 w-3"/></button><button className="rounded-lg border px-2 py-1 text-destructive" onClick={()=>void deleteProduct(p)}>Delete</button></div></td></tr>)}{tab==="orders"&&filteredOrders.map(o=><tr key={o.id}><td className="px-4 py-3 font-semibold">{o.order_number}</td><td className="px-4 py-3">{o.customers?.full_name||"—"}<p className="text-xs text-muted-foreground">{o.customers?.phone_normalized||""}</p></td><td className="px-4 py-3">{formatPrice(Number(o.total))}</td><td className="px-4 py-3">{new Date(o.created_at).toLocaleDateString("bn-BD")}</td><td className="px-4 py-3">{o.status}</td><td className="px-4 py-3"><select className="rounded-lg border bg-background p-2" value={o.status} onChange={e=>void changeOrderStatus(o,e.target.value)}>{["pending","confirmed","processing","shipped","delivered","cancelled"].map(s=><option key={s}>{s}</option>)}</select></td></tr>)}{tab==="customers"&&filteredCustomers.map(c=><tr key={c.id}><td className="px-4 py-3 font-semibold">{c.full_name}</td><td className="px-4 py-3"><a className="text-primary underline" href={`tel:${c.phone_normalized}`}>{c.phone_normalized}</a></td><td className="px-4 py-3">{c.email||"—"}</td><td className="px-4 py-3">{[c.address,c.area,c.district].filter(Boolean).join(", ")||"—"}</td><td className="px-4 py-3">{new Date(c.created_at).toLocaleDateString("bn-BD")}</td></tr>)}{((tab==="products"&&!filteredProducts.length)||(tab==="orders"&&!filteredOrders.length)||(tab==="customers"&&!filteredCustomers.length))&&<tr><td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">কোনো রেকর্ড পাওয়া যায়নি। Migration প্রয়োগ করা হয়েছে এবং সঠিক Supabase admin access আছে কি না যাচাই করুন।</td></tr>}</tbody></table></div>}
    <p className="mt-4 text-xs text-muted-foreground">Customer তথ্য শুধু admin role-এ দেখানো হয়। CSV export এখনো চালু করা হয়নি; ব্যক্তিগত তথ্য export-এর আগে অনুমোদন ও audit logging যোগ করতে হবে।</p>
  </div>;
}
