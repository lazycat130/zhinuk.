import { createFileRoute } from "@tanstack/react-router";
import { InfoPage } from "@/components/store/InfoPage";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "যোগাযোগ — ঝিনুক" },
      { name: "description", content: "ঝিনুক কাস্টমার সাপোর্টের সাথে যোগাযোগ করুন।" },
      { property: "og:title", content: "যোগাযোগ — ঝিনুক" },
      { property: "og:description", content: "ঝিনুক কাস্টমার সাপোর্টের সাথে যোগাযোগ করুন।" },
    ],
  }),
  component: () => (
    <InfoPage title="যোগাযোগ">
      <p>ফোন: +৮৮০ ১৭০০-০০০০০০</p><p>ইমেইল: support@zhinuk.com</p><p>ঠিকানা: গুলশান-২, ঢাকা ১২১২</p>
    </InfoPage>
  ),
});
