import { createFileRoute } from "@tanstack/react-router";
import { InfoPage } from "@/components/store/InfoPage";

export const Route = createFileRoute("/track")({
  head: () => ({
    meta: [
      { title: "অর্ডার ট্র্যাকিং — ঝিনুক" },
      { name: "description", content: "আপনার অর্ডারের অবস্থা জানুন।" },
      { property: "og:title", content: "অর্ডার ট্র্যাকিং — ঝিনুক" },
      { property: "og:description", content: "আপনার অর্ডারের অবস্থা জানুন।" },
    ],
  }),
  component: () => (
    <InfoPage title="অর্ডার ট্র্যাকিং">
      <form className="flex gap-2" onSubmit={(e) => e.preventDefault()}><input className="h-11 flex-1 rounded-xl border border-input px-4" placeholder="অর্ডার নম্বর লিখুন" /><button className="rounded-full bg-primary px-6 font-semibold text-primary-foreground">খুঁজুন</button></form>
    </InfoPage>
  ),
});
