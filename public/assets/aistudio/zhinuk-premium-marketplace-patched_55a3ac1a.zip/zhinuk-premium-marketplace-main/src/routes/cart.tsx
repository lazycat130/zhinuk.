import { createFileRoute, Link } from "@tanstack/react-router";
import { Trash2 } from "lucide-react";
import { formatPrice } from "@/lib/catalog";
import { useStore } from "@/lib/store";
import { QtyControl } from "@/components/store/CartDrawer";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "শপিং কার্ট — ঝিনুক" },
      { name: "description", content: "আপনার কার্টের পণ্য দেখুন ও চেকআউট করুন।" },
      { property: "og:title", content: "শপিং কার্ট — ঝিনুক" },
      { property: "og:description", content: "আপনার কার্টের পণ্য দেখুন।" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const { lines, subtotal, remove } = useStore();
  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold text-navy">শপিং কার্ট</h1>
      {lines.length === 0 ? (
        <p className="rounded-2xl bg-card p-10 text-center shadow-card">কার্ট খালি। <Link to="/shop" className="text-primary underline">কেনাকাটা করুন</Link></p>
      ) : (
        <div className="grid gap-6 md:grid-cols-[1fr_300px]">
          <ul className="divide-y divide-border rounded-2xl border border-border bg-card px-4 shadow-card">
            {lines.map(({ product, qty }) => (
              <li key={product.id} className="flex items-center gap-4 py-4">
                <img src={product.image} alt="" className="h-20 w-20 shrink-0 rounded-xl border border-border object-contain p-1" />
                <div className="min-w-0 flex-1">
                  <Link to="/product/$id" params={{ id: product.id }} className="block truncate font-medium hover:text-primary">{product.name}</Link>
                  <p className="text-sm text-muted-foreground">{formatPrice(product.price)}</p>
                </div>
                <QtyControl id={product.id} qty={qty} />
                <p className="hidden w-24 text-right font-semibold sm:block">{formatPrice(product.price * qty)}</p>
                <button aria-label="সরান" onClick={() => remove(product.id)} className="text-muted-foreground hover:text-destructive"><Trash2 className="h-4 w-4" /></button>
              </li>
            ))}
          </ul>
          <div className="h-fit space-y-4 rounded-2xl border border-border bg-card p-5 shadow-card">
            <div className="flex justify-between font-semibold"><span>সাবটোটাল</span><span>{formatPrice(subtotal)}</span></div>
            <p className="text-xs text-muted-foreground">ডেলিভারি চার্জ চেকআউটে যোগ হবে।</p>
            <Link to="/checkout" className="flex h-11 items-center justify-center rounded-full bg-primary font-semibold text-primary-foreground hover:bg-navy">চেকআউট করুন</Link>
          </div>
        </div>
      )}
    </div>
  );
}
