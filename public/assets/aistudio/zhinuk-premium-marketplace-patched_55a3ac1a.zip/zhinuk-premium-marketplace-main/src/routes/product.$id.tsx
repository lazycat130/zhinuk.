import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { ShoppingCart, Truck, ShieldCheck } from "lucide-react";
import { discountPct, formatPrice, getCategory, getProduct, products, toBn } from "@/lib/catalog";
import { useStore } from "@/lib/store";
import { ProductGrid, Rating, WishlistButton } from "@/components/store/ProductCard";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const product = getProduct(params.id);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.product.name} — ঝিনুক` },
          { name: "description", content: loaderData.product.description },
          { property: "og:title", content: `${loaderData.product.name} — ঝিনুক` },
          { property: "og:description", content: loaderData.product.description },
        ]
      : [{ title: "পণ্য পাওয়া যায়নি — ঝিনুক" }, { name: "robots", content: "noindex" }],
  }),
  notFoundComponent: () => <p className="py-24 text-center">পণ্যটি পাওয়া যায়নি। <Link to="/shop" className="text-primary underline">শপে ফিরুন</Link></p>,
  component: ProductPage,
});

function ProductPage() {
  const { product } = Route.useLoaderData();
  const { add } = useStore();
  const [qty, setQty] = useState(1);
  const off = discountPct(product);
  const related = products.filter((p) => p.id !== product.id).slice(0, 6);
  return (
    <div className="mx-auto max-w-[1440px] px-4 py-8 lg:px-8">
      <p className="mb-4 text-sm text-muted-foreground">
        <Link to="/" className="hover:text-primary">হোম</Link> / <Link to="/shop" search={{ cat: product.category }} className="hover:text-primary">{getCategory(product.category)?.name}</Link> / {product.name}
      </p>
      <div className="grid gap-8 rounded-3xl border border-border bg-card p-4 shadow-card md:grid-cols-2 md:p-8">
        <div className="relative rounded-2xl bg-card">
          <img src={product.image} alt={product.name} width={816} height={816} className="mx-auto aspect-square w-full max-w-lg object-contain" />
          <WishlistButton id={product.id} className="absolute right-2 top-2 h-10 w-10 border border-border" />
        </div>
        <div className="flex flex-col gap-4">
          <h1 className="text-2xl font-bold text-navy sm:text-3xl">{product.name}</h1>
          <Rating value={product.rating} reviews={product.reviews} />
          <div className="flex items-baseline gap-3">
            <span className="text-3xl font-bold text-destructive">{formatPrice(product.price)}</span>
            {product.regularPrice && <s className="text-muted-foreground">{formatPrice(product.regularPrice)}</s>}
            {off > 0 && <span className="rounded-full bg-highlight px-2 py-0.5 text-xs font-bold text-highlight-foreground">-{toBn(off)}%</span>}
          </div>
          <p className="text-muted-foreground">{product.description}</p>
          <div className="flex items-center gap-3">
            <div className="flex h-11 items-center rounded-full border border-border">
              <button className="h-11 w-11" aria-label="কমান" onClick={() => setQty(Math.max(1, qty - 1))}>−</button>
              <span className="w-8 text-center">{toBn(qty)}</span>
              <button className="h-11 w-11" aria-label="বাড়ান" onClick={() => setQty(qty + 1)}>+</button>
            </div>
            <button onClick={() => add(product.id, qty)} className="flex h-11 flex-1 items-center justify-center gap-2 rounded-full bg-primary font-semibold text-primary-foreground transition hover:bg-navy sm:flex-none sm:px-8">
              <ShoppingCart className="h-5 w-5" /> কার্টে যোগ করুন
            </button>
          </div>
          <ul className="space-y-2 rounded-2xl bg-ocean-soft p-4 text-sm">
            <li className="flex gap-2"><Truck className="h-5 w-5 text-primary" /> ঢাকায় ১-২ দিন, বাইরে ৩-৫ দিনে ডেলিভারি</li>
            <li className="flex gap-2"><ShieldCheck className="h-5 w-5 text-primary" /> ১০০% অরিজিনাল ও ৭ দিনের সহজ রিটার্ন</li>
          </ul>
        </div>
      </div>
      <h2 className="mb-4 mt-10 text-xl font-bold text-navy">আপনার পছন্দ হতে পারে</h2>
      <ProductGrid products={related} />
    </div>
  );
}
