import { createFileRoute } from "@tanstack/react-router";
import { InfoPage } from "@/components/store/InfoPage";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "আমাদের সম্পর্কে — ঝিনুক" },
      { name: "description", content: "ঝিনুক — ভালো পণ্যের নির্ভরযোগ্য ঠিকানা।" },
      { property: "og:title", content: "আমাদের সম্পর্কে — ঝিনুক" },
      { property: "og:description", content: "ঝিনুক — ভালো পণ্যের নির্ভরযোগ্য ঠিকানা।" },
    ],
  }),
  component: () => (
    <InfoPage title="আমাদের সম্পর্কে">
      <p className="text-muted-foreground">ঝিনুক একটি বাংলাদেশি প্রিমিয়াম অনলাইন শপ। আমরা যাচাই করা অরিজিনাল পণ্য বাছাই করি এবং সারা দেশে ক্যাশ অন ডেলিভারিতে পৌঁছে দিই। ৭ দিনের মধ্যে সহজ রিটার্ন ও এক্সচেঞ্জ সুবিধা রয়েছে।</p>
    </InfoPage>
  ),
});
