import { createFileRoute } from "@tanstack/react-router";
import { InfoPage } from "@/components/store/InfoPage";

export const Route = createFileRoute("/account")({
  head: () => ({
    meta: [
      { title: "আমার অ্যাকাউন্ট — ঝিনুক" },
      { name: "description", content: "আপনার ঝিনুক অ্যাকাউন্ট।" },
      { property: "og:title", content: "আমার অ্যাকাউন্ট — ঝিনুক" },
      { property: "og:description", content: "আপনার ঝিনুক অ্যাকাউন্ট।" },
    ],
  }),
  component: () => (
    <InfoPage title="আমার অ্যাকাউন্ট">
      <p className="text-muted-foreground">অ্যাকাউন্ট ও লগইন সুবিধা শীঘ্রই আসছে।</p>
    </InfoPage>
  ),
});
