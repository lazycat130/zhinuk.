import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2 } from "lucide-react";
import { DELIVERY_DHAKA, DELIVERY_OUTSIDE, formatPrice, toBn } from "@/lib/catalog";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "চেকআউট — ঝিনুক" },
      { name: "description", content: "ঠিকানা দিন ও অর্ডার নিশ্চিত করুন।" },
      { property: "og:title", content: "চেকআউট — ঝিনুক" },
      { property: "og:description", content: "অর্ডার নিশ্চিত করুন।" },
    ],
  }),
  component: Checkout,
});

const field = "h-11 w-full rounded-xl border border-input bg-card px-4 text-sm outline-none focus:border-ocean focus:ring-4 focus:ring-ocean/15";

function Checkout() {
  const { lines, subtotal, clear } = useStore();
  const [area, setArea] = useState<"dhaka" | "outside">("dhaka");
  const [pay, setPay] = useState("cod");
  const [orderNo, setOrderNo] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [idempotencyKey] = useState(() => crypto.randomUUID());
  const [customer, setCustomer] = useState({ name: "", phone: "", email: "", address: "", district: "", area: "" });
  const delivery = area === "dhaka" ? DELIVERY_DHAKA : DELIVERY_OUTSIDE;

  const submitOrder = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    try {
      const { data, error } = await (supabase as any).rpc("place_zhinuk_order", {
        p_name: customer.name, p_phone: customer.phone, p_email: customer.email || null,
        p_address: customer.address, p_district: customer.district, p_area: customer.area,
        p_delivery_zone: area, p_payment_method: pay, p_delivery_charge: delivery,
        p_items: lines.map(({ product, qty }) => ({ product_id: product.id, quantity: qty, variant: {} })),
        p_idempotency_key: idempotencyKey,
      });
      if (error) throw error;
      if (!data?.order_number) throw new Error("সার্ভার অর্ডার নম্বর ফেরত দেয়নি।");
      setOrderNo(String(data.order_number));
      clear();
    } catch (err: any) { toast.error("অর্ডার করা যায়নি", { description: err?.message || "Supabase migration, product stock এবং connection যাচাই করুন।" }); }
    finally { setSubmitting(false); }
  };

  if (orderNo)
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <CheckCircle2 className="mx-auto h-16 w-16 text-primary" />
        <h1 className="mt-4 text-2xl font-bold text-navy">ধন্যবাদ! অর্ডার সম্পন্ন হয়েছে</h1>
        <p className="mt-2 text-muted-foreground">অর্ডার নম্বর: #{toBn(orderNo)}। শীঘ্রই আমরা আপনাকে কল করব।</p>
        <Link to="/shop" className="mt-6 inline-flex rounded-full bg-primary px-6 py-2.5 font-semibold text-primary-foreground">আরও কেনাকাটা করুন</Link>
      </div>
    );

  if (!lines.length)
    return <p className="py-24 text-center">কার্ট খালি। <Link to="/shop" className="text-primary underline">শপে যান</Link></p>;

  return (
    <form
      onSubmit={submitOrder}
      className="mx-auto grid max-w-5xl gap-6 px-4 py-8 md:grid-cols-[1fr_340px]"
    >
      <div className="space-y-4 rounded-2xl border border-border bg-card p-5 shadow-card">
        <h1 className="text-2xl font-bold text-navy">ডেলিভারি তথ্য</h1>
        <input required minLength={2} className={field} placeholder="আপনার নাম" value={customer.name} onChange={e=>setCustomer({...customer,name:e.target.value})} />
        <input required type="tel" inputMode="tel" className={field} placeholder="মোবাইল নম্বর (01XXXXXXXXX)" value={customer.phone} onChange={e=>setCustomer({...customer,phone:e.target.value})} />
        <input type="email" className={field} placeholder="ইমেইল (ঐচ্ছিক)" value={customer.email} onChange={e=>setCustomer({...customer,email:e.target.value})} />
        <textarea required minLength={5} className={`${field} h-24 py-3`} placeholder="সম্পূর্ণ ঠিকানা" value={customer.address} onChange={e=>setCustomer({...customer,address:e.target.value})} />
        <div className="grid grid-cols-2 gap-3"><input className={field} placeholder="জেলা" value={customer.district} onChange={e=>setCustomer({...customer,district:e.target.value})}/><input className={field} placeholder="এলাকা" value={customer.area} onChange={e=>setCustomer({...customer,area:e.target.value})}/></div>
        <div className="grid grid-cols-2 gap-3">
          {(["dhaka", "outside"] as const).map((a) => (
            <label key={a} className={`cursor-pointer rounded-xl border p-3 text-sm ${area === a ? "border-primary bg-ocean-soft" : "border-border"}`}>
              <input type="radio" className="sr-only" checked={area === a} onChange={() => setArea(a)} />
              {a === "dhaka" ? "ঢাকার ভেতরে" : "ঢাকার বাইরে"} — {formatPrice(a === "dhaka" ? DELIVERY_DHAKA : DELIVERY_OUTSIDE)}
            </label>
          ))}
        </div>
        <h2 className="pt-2 font-semibold">পেমেন্ট পদ্ধতি</h2>
        <div className="rounded-xl border border-primary bg-ocean-soft p-3 text-sm font-medium">✓ ক্যাশ অন ডেলিভারি (COD)</div>
        <p className="text-xs text-muted-foreground">বিকাশ/নগদ অনলাইন পেমেন্ট গেটওয়ে এখনো সংযুক্ত হয়নি, তাই আপাতত COD-ই চালু আছে।</p>
      </div>
      <div className="h-fit space-y-3 rounded-2xl border border-border bg-card p-5 shadow-card">
        <h2 className="font-semibold">অর্ডার সারাংশ</h2>
        {lines.map(({ product, qty }) => (
          <div key={product.id} className="flex justify-between gap-2 text-sm"><span className="truncate">{product.name} × {toBn(qty)}</span><span className="shrink-0">{formatPrice(product.price * qty)}</span></div>
        ))}
        <hr className="border-border" />
        <div className="flex justify-between text-sm"><span>সাবটোটাল</span><span>{formatPrice(subtotal)}</span></div>
        <div className="flex justify-between text-sm"><span>ডেলিভারি</span><span>{formatPrice(delivery)}</span></div>
        <div className="flex justify-between text-lg font-bold"><span>মোট</span><span>{formatPrice(subtotal + delivery)}</span></div>
        <button disabled={submitting} className="h-11 w-full rounded-full bg-primary font-semibold text-primary-foreground hover:bg-navy disabled:opacity-60">{submitting ? "অর্ডার সংরক্ষণ হচ্ছে…" : "অর্ডার নিশ্চিত করুন"}</button>
      </div>
    </form>
  );
}
