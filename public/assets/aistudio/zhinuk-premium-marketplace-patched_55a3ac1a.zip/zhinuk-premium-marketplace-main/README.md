# Zhinuk Premium Marketplace

# ZHINUK — MASTER WEBSITE BUILD PROMPT

You are building the official e-commerce website for **ZHINUK (ঝিনুক)**, a premium Bengali online shopping brand.

## MOST IMPORTANT RULE

The attached reference screenshot is the **SOURCE OF TRUTH for the visual design**.

Do NOT redesign it.
Do NOT invent a different layout.
Do NOT simplify it.
Do NOT replace important visual elements with generic placeholders.

Your goal is to reproduce the reference design as faithfully as possible while making it responsive, polished, modern, and production-ready.

If there is any conflict between your own design preference and the reference screenshot, **ALWAYS follow the reference screenshot**.

---

# 1. BRAND

Brand name:

**ZHINUK**
**ঝিনুক**

Brand feeling:
- Premium
- Elegant
- Modern
- Trustworthy
- Bengali-friendly
- Fashion + lifestyle + technology marketplace

Primary visual character:
- Deep navy
- White
- Soft ocean blue
- Pearl/cream accents
- Clean rounded cards
- Premium photography
- Subtle shadows
- Spacious layout

Do not use a generic startup/SaaS visual style.

This is an **e-commerce store**, not a SaaS landing page.

---

# 2. HEADER

Recreate the header from the reference screenshot.

Desktop header structure:

### Top utility bar
Dark navy background.

Include Bengali-friendly utility links such as:
- যোগাযোগ
- সাহায্য
- অর্ডার ট্র্যাকিং

Keep this bar compact.

### Main header
White background.

Left:
- ZHINUK logo
- Bengali brand identity

Center:
Large search bar.

Search placeholder:

"আপনি কী খুঁজছেন?"

Search bar should have:
- rounded corners
- search icon
- clean border
- comfortable height
- desktop-first proportions

Right:
- Wishlist icon
- Cart icon
- User/account icon where appropriate

Show cart count using a small badge.

### Navigation

Below the main header, create a clean navigation menu.

Example:

হোম
ক্যাটাগরি
ফ্যাশন
ইলেকট্রনিক্স
বিউটি
লাইফস্টাইল
অফার

Navigation should visually match the screenshot.

---

# 3. HERO SECTION

This is one of the most important sections.

Recreate the hero composition shown in the reference screenshot.

The hero should feel like a premium Bangladeshi e-commerce marketplace.

Use a large visual composition containing real-looking product photography such as:

- handbag
- smartphone
- perfume
- wristwatch
- pearl/shell
- shoes
- headphones

Do NOT use boring gray placeholder boxes.

Do NOT use random SaaS illustrations.

The products should be arranged into an attractive collage similar to the reference.

Include the main Bengali promotional messaging.

Example:

"আপনার পছন্দ,
আমাদের যত্নে"

Supporting text should communicate:
quality products, trusted shopping, and easy delivery.

Primary CTA:

"এখনই কেনাকাটা করুন"

Secondary CTA where appropriate:

"সব পণ্য দেখুন"

Hero should have:
- strong visual hierarchy
- rounded visual elements
- subtle shadows
- premium product photography
- responsive layout

On mobile, convert the collage into a clean stacked/controlled layout instead of allowing products to overlap badly.

---

# 4. CATEGORY SECTION

Immediately after the hero, create a horizontal category section.

Categories should use **real visual icons/images**, NOT dots.

Example categories:

- ফ্যাশন
- ইলেকট্রনিক্স
- বিউটি
- ঘড়ি
- ব্যাগ
- জুতা
- গ্যাজেট
- লাইফস্টাইল

Each category:

- circular image/icon
- category name underneath
- clean spacing
- subtle hover animation
- premium appearance

The circular category images must visually resemble the reference.

Do NOT replace them with tiny generic colored circles.

---

# 5. PROMOTIONAL BANNERS

Create the two promotional banner sections visible in the reference.

Use wide rounded cards.

Banner content should include Bengali promotional messaging.

Examples:

"আজকের বিশেষ অফার"

"ফ্যাশনে নতুন কালেকশন"

Use attractive product imagery.

Each banner should have an appropriate CTA.

Example:

"এখনই দেখুন"

Maintain the visual hierarchy and proportions from the reference screenshot.

---

# 6. POPULAR PRODUCTS

Create a premium product section.

Heading:

"জনপ্রিয় পণ্য"

Optional subtitle:

"আপনার জন্য বেছে নেওয়া কিছু জনপ্রিয় পণ্য"

Create product cards matching the reference.

Each product card must include:

- real product image
- product name
- category
- current price
- optional old price
- discount badge when applicable
- rating
- wishlist heart
- Add to Cart button

Example products:

1. Premium Leather Handbag
2. Smart Watch
3. Wireless Headphones
4. Premium Perfume
5. Smartphone
6. Casual Shoes

Use realistic product photography.

Do NOT use blank placeholders.

Product cards should have:
- white background
- rounded corners
- subtle shadow
- consistent image ratio
- clean typography
- comfortable spacing

Hover effect:
- slightly lift card
- reveal subtle action
- do not create excessive animations

---

# 7. SERVICE / TRUST STRIP

Create the service benefits section visible in the reference.

Use four columns/items.

Example:

🚚 দ্রুত ডেলিভারি
"সারা দেশে দ্রুত ডেলিভারি"

🔒 নিরাপদ পেমেন্ট
"নিরাপদ ও নির্ভরযোগ্য পেমেন্ট"

↩️ সহজ রিটার্ন
"সহজ রিটার্ন সুবিধা"

💬 কাস্টমার সাপোর্ট
"প্রয়োজনে আমরা পাশে আছি"

Use simple premium icons.

---

# 8. OCEAN / PEARL BRAND SECTION

The reference contains a distinctive water/ocean-inspired brand section.

This section is important to Zhinuk's identity.

Create a visually rich section inspired by:

- ocean water
- pearl
- shell
- purity
- trust

Use a premium blue/ocean background with subtle gradients and realistic pearl/shell imagery.

The section should communicate:

"ঝিনুক — ভালো পণ্যের নির্ভরযোগ্য ঠিকানা"

Do NOT make it look like a generic blue gradient SaaS section.

It should feel connected to the brand name "ঝিনুক".

---

# 9. FOOTER

Create a dark navy premium footer.

Columns:

### ZHINUK
Brief Bengali brand description.

### দ্রুত লিংক
- হোম
- আমাদের সম্পর্কে
- যোগাযোগ
- শপ

### কাস্টমার সার্ভিস
- সাহায্য কেন্দ্র
- অর্ডার ট্র্যাকিং
- রিটার্ন পলিসি
- ডেলিভারি তথ্য

### যোগাযোগ
- ফোন
- ইমেইল
- ঠিকানা

Include social media icons.

Bottom:

© 2026 ZHINUK. সর্বস্বত্ব সংরক্ষিত।

Footer must visually match the premium navy identity.

---

# 10. TYPOGRAPHY

The site must support Bengali properly.

Use a high-quality Bengali web font such as:

**Noto Sans Bengali**

Use appropriate font weights:
- headings: 600–700
- body: 400–500
- buttons: 500–600

Avoid awkward Bengali rendering.

Do NOT use a font that breaks Bengali characters.

---

# 11. RESPONSIVE DESIGN

The site must be fully responsive.

Desktop:
- match the reference screenshot closely
- wide content area
- balanced spacing

Tablet:
- adjust grids
- preserve visual hierarchy

Mobile:
- hamburger navigation
- compact header
- full-width search
- hero becomes vertical
- product grids become 2 columns
- category section becomes horizontally scrollable
- banners stack vertically
- footer becomes stacked

Do NOT simply shrink the desktop design.

Create a deliberate mobile layout.

---

# 12. VISUAL QUALITY

Use:

- high-quality product photography
- realistic images
- subtle shadows
- premium rounded corners
- consistent spacing
- elegant hover effects
- smooth transitions
- clean alignment

Avoid:

- generic placeholders
- excessive gradients
- giant text
- random icons
- excessive animations
- SaaS-style cards
- childish colors
- inconsistent spacing
- empty sections

---

# 13. IMPORTANT: IMAGE HANDLING

Where possible, use appropriate real product images.

For product cards, choose visually relevant images:
- handbags should look like handbags
- phones should look like smartphones
- watches should look like watches
- perfume should look like perfume
- shoes should look like shoes
- headphones should look like headphones

Do not use the same image repeatedly.

Do not use unrelated stock images.

If exact reference images are unavailable, choose visually similar premium product photography.

---

# 14. E-COMMERCE FUNCTIONALITY

This should behave like a real e-commerce website.

Implement:

- product browsing
- category browsing
- product detail pages
- search UI
- wishlist UI
- shopping cart
- quantity controls
- add to cart
- remove from cart
- checkout flow
- responsive navigation

The architecture must be suitable for later integration with WooCommerce.

Do not hard-code the entire store as one static landing page.

Use reusable components.

---

# 15. COMPONENT STRUCTURE

Create reusable components for:

Header
Navigation
Hero
CategoryCard
CategorySection
PromoBanner
ProductCard
ProductGrid
ServiceFeature
OceanBrandSection
Footer
MobileNavigation
CartDrawer
WishlistButton

Keep the code clean and maintainable.

Do not duplicate large blocks of code.

---

# 16. INTERACTION

Add subtle interactions:

- search focus effect
- product hover
- wishlist toggle
- cart badge update
- add-to-cart feedback
- smooth scrolling
- navigation hover
- button hover
- mobile menu animation

Animations must be subtle.

The site should feel premium, not flashy.

---

# 17. DESIGN VALIDATION

After building the page:

1. Compare the result visually against the reference screenshot.
2. Check header proportions.
3. Check hero composition.
4. Check category circles.
5. Check promotional banners.
6. Check product card spacing.
7. Check footer height.
8. Check typography.
9. Check colors.
10. Check mobile responsiveness.

If something does not resemble the reference, FIX IT.

Do not simply tell me that the implementation is approximate.

---

# 18. VERY IMPORTANT — DO NOT CHANGE THE DESIGN

Do not make creative design decisions that move away from the reference.

Do NOT:
- change the overall layout
- remove sections
- invent new sections
- replace product imagery with placeholders
- turn the site into a SaaS dashboard
- use a completely different color palette
- make the hero generic
- replace Bengali content with English
- simplify the page into a basic template

The reference screenshot is the visual authority.

---

# 19. FINAL QUALITY REQUIREMENT

The final result should look like a **real premium Bangladeshi e-commerce website**, not an AI-generated demo.

It should be:

- polished
- trustworthy
- commercial
- responsive
- visually rich
- Bengali-first
- WooCommerce-ready
- maintainable

Most importantly:

**The final visual appearance must closely match the supplied Zhinuk reference screenshot.**

Before considering the task complete, perform a visual review and fix any obvious mismatch.

Do not stop at the first acceptable version.

Build → compare → refine → compare again.

## FINAL INSTRUCTION

Treat the supplied screenshot as the design specification.

**Faithful reproduction is more important than your own design creativity.**

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/9f21a057-d0dc-4cd8-8ca8-68cde1d64a40).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
