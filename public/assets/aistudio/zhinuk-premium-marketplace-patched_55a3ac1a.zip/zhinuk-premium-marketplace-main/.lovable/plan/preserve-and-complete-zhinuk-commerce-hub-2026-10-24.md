# Preserve and complete Zhinuk Commerce Hub

## Verified first: original logo and demo products
- The existing homepage currently renders the original logo and all eight original demo product links. All homepage images loaded successfully.
- Desktop and phone screenshots confirm the existing Blue Ocean appearance; the phone page has no horizontal overflow.
- The reported disappearance could not be reproduced in this project. Preserve the recovered sources as-is rather than invent replacements or claim a restoration occurred.

## What will change
1. **Preserve the shop and correct contact details.** Keep the homepage, logo, banners, categories, cart and wishlist. Use clickable **01823-824071** and **email-admin@zhinuk.com** for business support. Clearly distinguish demo content from genuine reviews or sales.
2. **Connect Lovable Cloud.** This project currently uses frontend catalog fixtures and has no connected database or working administrator authentication. Add persistent product records, image storage, orders and customers without deleting the original fixtures. Keep demo products separate from published real products; do not silently turn fixtures into genuine inventory.
3. **Secure administrator access.** Add sign-in and a protected dashboard at **/admin**, with server-enforced administrator permissions. Administrator access must be granted to a verified account, never inferred from the business email. Non-admins cannot read customer information or manage the shop.
4. **Complete product management.** Support Bengali/English names, unique SKU, category/subcategory, uploaded gallery images with preview/reordering/removal, prices and calculated discounts, stock/thresholds, variants, descriptions, specifications, package contents, warranty and delivery/return settings. Add draft, publish, edit, archive and named deletion confirmation. Preserve order snapshots when products change or are archived.
5. **Compact product pages and genuine orders.** Use the requested three-column desktop layout, stacked phone layout, information tabs and a sticky phone order bar. The order form captures name, Bangladesh phone, optional email, address, district, area, quantity and delivery choice. Validate availability and calculate authoritative totals on the server; atomically save orders and update stock. Prevent duplicate submissions. Replace the existing simulated checkout confirmation with confirmation only after a saved order.
6. **Orders and customers.** Add searchable admin lists and customer profiles with actual order history, repeat-order counts, clickable phone numbers, authorized edits and restricted CSV export. Support Pending, Confirmed, Processing, Shipped, Delivered and Cancelled statuses. Preserve private customer and order records.
7. **Meta Pixel.** Inspect for existing installations, add consent-aware event handling without duplicate route events, and support a configurable real Pixel ID. Send product/cart/checkout events at the actual interaction and Purchase only after a valid saved order and applicable purchase criteria. Do not invent a Pixel ID or enable Conversions API without credentials and deduplication.

## Technical approach
- Retain TanStack Start and existing design tokens/components. Record the updated catalog architecture in project guidance.
- Keep original fixtures as a separate demo source. Load published real products through safe public reads; owner/admin reads must also cover drafts and archived products.
- Use additive migrations with explicit grants, row-level security, a separate roles table and admin-only image writes. Customer and order data have no public read access.
- Use authenticated server functions for management and a validated public ordering function with transactional database logic, server-calculated totals, idempotency and stock locking. Do not accept client prices or caller-supplied administrator/owner identities.
- Provide meaningful page metadata on every content page and maintain the original shopping navigation.

## Verification and handover
- Check logo, eight demo fixtures, images, search, categories, detail links, cart and wishlist on desktop and phone.
- Test price/phone validation, publication visibility, permissions, stock safety and duplicate order handling with concrete automated checks.
- Exercise real product upload, draft/edit/publish/archive and refresh persistence, then place an order and read it back through the authorized dashboard and customer profile.
- Check signed-out/non-admin privacy and preserve product-linked order history.
- Report what was verified, dashboard navigation, management instructions and anything still requiring configuration.

## Configuration still needed
- Lovable Cloud activation approval, if requested by the connection dialog.
- A verified administrator account to receive administrator access; the business email is not assumed to be that account.
- The actual Meta Pixel ID and Meta testing access. Events cannot be claimed verified without them.
- Real product stock, variants and product-specific policy details where they are not already provided. Do not fabricate them for existing demo items.