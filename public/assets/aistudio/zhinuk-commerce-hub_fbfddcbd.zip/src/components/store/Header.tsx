import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Heart, Lock, Menu, Search, ShieldCheck, ShoppingCart, Truck, User, ChevronDown, Phone } from "lucide-react";
import logo from "@/assets/zhinuk-logo.png.asset.json";
import { categories, toBn } from "@/lib/catalog";
import { useStore } from "@/lib/store";
import { MobileNavigation } from "./MobileNavigation";

export const navLinks = [
  { label: "হোম", to: "/" as const },
  { label: "সকল পণ্য", to: "/shop" as const },
  { label: "নতুন পণ্য", to: "/shop" as const, search: { cat: "electronics" } },
  { label: "অফার", to: "/shop" as const, search: { offer: "1" } },
  { label: "ফ্যাশন", to: "/shop" as const, search: { cat: "fashion" } },
  { label: "বিউটি", to: "/shop" as const, search: { cat: "beauty" } },
  { label: "আমাদের সম্পর্কে", to: "/about" as const },
  { label: "যোগাযোগ", to: "/contact" as const },
];

export function SearchBar({ className = "" }: { className?: string }) {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        navigate({ to: "/shop", search: { q: q || undefined, cat: cat || undefined } });
      }}
      className={`flex h-12 items-center overflow-hidden rounded-full border border-input bg-card shadow-card transition focus-within:border-ocean focus-within:ring-4 focus-within:ring-ocean/15 ${className}`}
    >
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="আপনি কী খুঁজছেন?"
        aria-label="পণ্য খুঁজুন"
        className="h-full min-w-0 flex-1 bg-transparent px-5 text-sm outline-none placeholder:text-muted-foreground"
      />
      <div className="relative hidden h-6 items-center border-l border-border pl-3 md:flex">
        <select
          value={cat}
          onChange={(e) => setCat(e.target.value)}
          aria-label="ক্যাটাগরি"
          className="appearance-none bg-transparent pr-7 text-sm text-muted-foreground outline-none"
        >
          <option value="">সব ক্যাটাগরি</option>
          {categories.map((c) => (
            <option key={c.slug} value={c.slug}>{c.name}</option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-2 h-4 w-4 text-muted-foreground" />
      </div>
      <button type="submit" aria-label="খুঁজুন" className="ml-2 grid h-full w-16 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground transition hover:bg-navy">
        <Search className="h-5 w-5" />
      </button>
    </form>
  );
}

export function Header() {
  const { count, wishlist, setCartOpen } = useStore();
  return (
    <header className="sticky top-0 z-40 lg:static">
      <div className="bg-topbar text-navy-foreground">
        <div className="mx-auto flex h-10 max-w-[1440px] items-center justify-between gap-4 px-4 text-xs sm:text-sm lg:px-8">
          <div className="flex min-w-0 items-center gap-4 sm:gap-6 overflow-hidden">
            <div className="flex shrink-0 items-center gap-2 font-semibold">
              <Phone className="h-3.5 w-3.5 text-highlight" />
              <span className="text-navy-foreground/75 hidden sm:inline">হটলাইন:</span>
              <a href="tel:+8801823824071" className="text-highlight hover:underline">
                01823-824071
              </a>
              <span className="text-navy-foreground/40">|</span>
              <a href="tel:+8801552541791" className="text-navy-foreground hover:text-highlight hover:underline">
                01552-541791
              </a>
            </div>
            <span className="hidden items-center gap-2 md:flex"><Truck className="h-4 w-4" /> সারা বাংলাদেশে ডেলিভারি</span>
            <span className="hidden items-center gap-2 lg:flex"><ShieldCheck className="h-4 w-4" /> ১০০% আসল পণ্য ও ক্যাশ অন ডেলিভারি</span>
          </div>
          <div className="flex shrink-0 items-center gap-5">
            <Link to="/track" className="hidden hover:underline sm:inline">অর্ডার ট্র্যাকিং</Link>
            <Link to="/contact" className="hidden hover:underline sm:inline">যোগাযোগ</Link>
            <Link to="/admin" className="flex items-center gap-1.5 font-medium hover:underline text-highlight">
              <Lock className="h-3.5 w-3.5" /> অ্যাডমিন
            </Link>
          </div>
        </div>
      </div>

      <div className="border-b border-border/60 bg-card/90 backdrop-blur lg:border-0 lg:bg-transparent lg:backdrop-blur-none">
        <div className="mx-auto grid max-w-[1440px] grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 px-4 py-2 lg:grid-cols-[240px_minmax(0,1fr)_auto] lg:gap-10 lg:px-8 lg:py-3">
          <div className="flex items-center gap-2">
            <MobileNavigation trigger={<button aria-label="মেনু" className="grid h-10 w-10 place-items-center rounded-full hover:bg-muted lg:hidden"><Menu className="h-6 w-6" /></button>} />
            <Link to="/" aria-label="ঝিনুক হোম" className="block group">
              <img
                src="/zhinuk-logo-transparent.png"
                alt="ঝিনুক — Premium Pearls"
                className="h-11 sm:h-14 lg:h-16 w-auto max-w-[180px] sm:max-w-[220px] object-contain transition-transform duration-250 ease-out group-hover:scale-105"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = "/zhinuk-original-logo.png";
                }}
              />
            </Link>
          </div>
          <SearchBar className="hidden max-w-[660px] lg:flex" />
          <div className="col-start-3 flex items-center gap-2 sm:gap-6">
            <Link to="/wishlist" className="group relative flex flex-col items-center gap-1 text-sm text-foreground">
              <Heart className="h-7 w-7 text-primary transition group-hover:scale-110" strokeWidth={1.6} />
              {wishlist.length > 0 && <Badge n={wishlist.length} />}
              <span className="hidden sm:block">পছন্দের তালিকা</span>
            </Link>
            <button onClick={() => setCartOpen(true)} className="group relative flex flex-col items-center gap-1 text-sm">
              <ShoppingCart className="h-7 w-7 text-primary transition group-hover:scale-110" strokeWidth={1.6} />
              <Badge n={count} />
              <span className="hidden sm:block">কার্ট</span>
            </button>
          </div>
        </div>
        <div className="px-4 pb-3 lg:hidden"><SearchBar /></div>
      </div>
    </header>
  );
}

function Badge({ n }: { n: number }) {
  return (
    <span key={n} className="absolute -right-2 -top-2 grid h-5 min-w-5 animate-in zoom-in place-items-center rounded-full bg-highlight px-1 text-[11px] font-semibold text-highlight-foreground">
      {toBn(n)}
    </span>
  );
}
