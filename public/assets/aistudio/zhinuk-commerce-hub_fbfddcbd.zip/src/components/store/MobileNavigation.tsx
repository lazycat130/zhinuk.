import { Link } from "@tanstack/react-router";
import { useState, type ReactElement } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { categories } from "@/lib/catalog";
import { navLinks } from "./Header";
import { Phone } from "lucide-react";

export function MobileNavigation({ trigger }: { trigger: ReactElement }) {
  const [open, setOpen] = useState(false);
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent side="left" className="w-[86vw] max-w-sm overflow-y-auto p-0 flex flex-col justify-between">
        <div>
          <SheetHeader className="border-b border-border p-4 bg-muted/20">
            <SheetTitle className="flex items-center">
              <img
                src="/zhinuk-logo-transparent.png"
                alt="ঝিনুক"
                className="h-12 w-auto max-w-[150px] object-contain"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = "/zhinuk-original-logo.png";
                }}
              />
            </SheetTitle>
          </SheetHeader>
          <ul className="p-2">
            {navLinks.map((l) => (
              <li key={l.label}>
                <Link to={l.to} search={("search" in l ? l.search : {}) as never} onClick={() => setOpen(false)} className="block rounded-lg px-4 py-3 font-medium hover:bg-muted text-navy">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <p className="px-6 pt-2 text-xs font-semibold text-muted-foreground">ক্যাটাগরি</p>
          <div className="grid grid-cols-4 gap-3 p-4">
            {categories.map((c) => (
              <Link key={c.slug} to="/shop" search={{ cat: c.slug }} onClick={() => setOpen(false)} className="flex flex-col items-center gap-1 text-center text-xs">
                <img src={c.image} alt="" className="h-14 w-14 rounded-full border border-border bg-card object-contain p-1.5" />
                {c.name}
              </Link>
            ))}
          </div>
        </div>

        {/* Hotlines footer in drawer */}
        <div className="border-t border-border p-4 bg-ocean-soft/50 space-y-2">
          <p className="text-xs font-bold text-navy flex items-center gap-1.5">
            <Phone className="h-3.5 w-3.5 text-primary" /> সরাসরি অর্ডার ও সহায়তা হটলাইন:
          </p>
          <div className="flex flex-col gap-1.5 text-xs font-semibold text-navy">
            <a href="tel:+8801823824071" className="hover:text-primary transition flex items-center justify-between bg-card rounded-lg px-3 py-1.5 border border-border">
              <span>০১৮২৩-৮২৪০৭১</span>
              <span className="text-[11px] text-muted-foreground font-normal">সরাসরি কল</span>
            </a>
            <a href="tel:+8801552541791" className="hover:text-primary transition flex items-center justify-between bg-card rounded-lg px-3 py-1.5 border border-border">
              <span>০১৫৫২-৫৪১৭৯১</span>
              <span className="text-[11px] text-muted-foreground font-normal">সরাসরি কল</span>
            </a>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
