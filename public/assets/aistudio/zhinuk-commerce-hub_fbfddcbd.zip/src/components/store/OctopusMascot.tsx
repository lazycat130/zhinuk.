import React from "react";

interface MascotProps {
  className?: string;
  variant?: "banner" | "footer" | "badge";
  size?: number;
}

/**
 * Cute, friendly ocean-themed octopus mascot for Zhinuk Commerce Hub.
 * Features an ocean-blue/aqua body, friendly rounded head, sparkling eyes,
 * joyful smile, rosy cheeks, curled tentacles, and subtle highlights.
 */
export function OctopusMascot({
  className = "",
  variant = "banner",
  size = 64,
}: MascotProps) {
  if (variant === "footer") {
    // Underwater scene variant: relaxing near pearl & bubbles
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`select-none ${className}`}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="octoGradientFooter" x1="20" y1="15" x2="80" y2="85" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#48CAE4" />
            <stop offset="50%" stopColor="#0096C7" />
            <stop offset="100%" stopColor="#023E8A" />
          </linearGradient>
          <linearGradient id="pearlGlow" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#EAF7FC" />
          </linearGradient>
          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Floating air bubbles */}
        <circle cx="20" cy="22" r="3.5" fill="#EAF7FC" fillOpacity="0.45" />
        <circle cx="21" cy="21" r="1.2" fill="#FFFFFF" fillOpacity="0.8" />
        <circle cx="30" cy="12" r="2" fill="#EAF7FC" fillOpacity="0.35" />
        <circle cx="85" cy="28" r="4" fill="#EAF7FC" fillOpacity="0.4" />
        <circle cx="86.5" cy="26.5" r="1.5" fill="#FFFFFF" fillOpacity="0.8" />

        {/* Tentacles */}
        <g stroke="url(#octoGradientFooter)" strokeWidth="6.5" strokeLinecap="round" strokeLinejoin="round">
          {/* Left tentacles */}
          <path d="M30 68 Q18 78 22 88 Q26 94 34 88" />
          <path d="M40 70 Q32 82 38 91 Q43 96 48 88" />
          {/* Middle/Right tentacles */}
          <path d="M58 70 Q62 84 56 92 Q52 96 60 92" />
          <path d="M68 68 Q78 80 74 90 Q70 96 80 88" />
          {/* Front friendly wave tentacle */}
          <path d="M26 60 Q12 56 16 46 Q20 38 28 48" />
        </g>

        {/* Cute Pearl Shell beside octopus */}
        <g transform="translate(68, 64) scale(0.32)">
          <path
            d="M50 85 C20 85 10 50 25 25 C35 10 65 10 75 25 C90 50 80 85 50 85 Z"
            fill="#EAF7FC"
            stroke="#90E0EF"
            strokeWidth="4"
          />
          {/* Pearl */}
          <circle cx="50" cy="52" r="14" fill="url(#pearlGlow)" filter="url(#softGlow)" />
          <circle cx="46" cy="48" r="4" fill="#FFFFFF" />
        </g>

        {/* Head / Body */}
        <ellipse cx="50" cy="48" rx="26" ry="24" fill="url(#octoGradientFooter)" />

        {/* Head Highlight */}
        <path
          d="M34 32 C38 28 46 26 56 27 C59 27.5 56 31 46 31 C38 31 35 34 34 32 Z"
          fill="#FFFFFF"
          fillOpacity="0.45"
        />

        {/* Cheeks */}
        <ellipse cx="36" cy="55" rx="3.5" ry="2" fill="#FF7900" fillOpacity="0.4" />
        <ellipse cx="64" cy="55" rx="3.5" ry="2" fill="#FF7900" fillOpacity="0.4" />

        {/* Sparkling Big Friendly Eyes */}
        <ellipse cx="40" cy="47" rx="4" ry="5" fill="#0B2F5B" />
        <circle cx="38.5" cy="45" r="1.8" fill="#FFFFFF" />
        <circle cx="41.5" cy="48.5" r="0.8" fill="#FFFFFF" />

        <ellipse cx="60" cy="47" rx="4" ry="5" fill="#0B2F5B" />
        <circle cx="58.5" cy="45" r="1.8" fill="#FFFFFF" />
        <circle cx="61.5" cy="48.5" r="0.8" fill="#FFFFFF" />

        {/* Happy smile */}
        <path d="M46 54 Q50 58 54 54" stroke="#0B2F5B" strokeWidth="2.2" strokeLinecap="round" fill="none" />
      </svg>
    );
  }

  // Default: Banner variant (Holding a neat mini package with friendly wave)
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none ${className}`}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="octoGradBanner" x1="20" y1="12" x2="80" y2="88" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#48CAE4" />
          <stop offset="45%" stopColor="#0096C7" />
          <stop offset="100%" stopColor="#0B2F5B" />
        </linearGradient>
        <linearGradient id="parcelGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FFF3E0" />
          <stop offset="100%" stopColor="#FFE0B2" />
        </linearGradient>
      </defs>

      {/* Tiny celebratory bubbles */}
      <circle cx="18" cy="20" r="3" fill="#0096C7" fillOpacity="0.25" />
      <circle cx="19" cy="19" r="1" fill="#FFFFFF" />
      <circle cx="28" cy="10" r="2" fill="#0096C7" fillOpacity="0.2" />
      <circle cx="86" cy="18" r="3.5" fill="#0096C7" fillOpacity="0.25" />
      <circle cx="87" cy="17" r="1.2" fill="#FFFFFF" />

      {/* Tentacles */}
      <g stroke="url(#octoGradBanner)" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M28 66 Q16 76 20 86 Q24 92 32 86" />
        <path d="M38 69 Q32 80 37 88 Q42 94 48 87" />
        <path d="M58 69 Q64 80 59 88 Q55 93 63 89" />
        <path d="M68 66 Q80 76 76 86 Q72 92 82 86" />
        {/* Friendly Waving Tentacle */}
        <path d="M25 56 Q10 50 14 38 Q18 30 26 40" />
      </g>

      {/* Head / Body */}
      <ellipse cx="50" cy="46" rx="25" ry="23" fill="url(#octoGradBanner)" />

      {/* Soft highlight on head */}
      <path
        d="M35 30 C39 26 47 24 57 25 C60 25.5 56 29 47 29 C40 29 36 32 35 30 Z"
        fill="#FFFFFF"
        fillOpacity="0.45"
      />

      {/* Cheeks */}
      <ellipse cx="37" cy="53" rx="3.5" ry="2" fill="#FF7900" fillOpacity="0.5" />
      <ellipse cx="63" cy="53" rx="3.5" ry="2" fill="#FF7900" fillOpacity="0.5" />

      {/* Big Friendly Eyes */}
      <ellipse cx="41" cy="45" rx="4" ry="4.8" fill="#0B2F5B" />
      <circle cx="39.5" cy="43.5" r="1.7" fill="#FFFFFF" />
      <circle cx="42.5" cy="46.5" r="0.7" fill="#FFFFFF" />

      <ellipse cx="59" cy="45" rx="4" ry="4.8" fill="#0B2F5B" />
      <circle cx="57.5" cy="43.5" r="1.7" fill="#FFFFFF" />
      <circle cx="60.5" cy="46.5" r="0.7" fill="#FFFFFF" />

      {/* Cheerful Smile */}
      <path d="M47 52 Q50 56 53 52" stroke="#0B2F5B" strokeWidth="2.2" strokeLinecap="round" fill="none" />

      {/* Cute mini delivery parcel held by right tentacle */}
      <g transform="translate(64, 46) rotate(6)">
        <rect x="0" y="0" width="20" height="17" rx="3" fill="url(#parcelGrad)" stroke="#FF7900" strokeWidth="1.5" />
        {/* Ribbon */}
        <line x1="10" y1="0" x2="10" y2="17" stroke="#FF7900" strokeWidth="1.8" />
        <line x1="0" y1="8.5" x2="20" y2="8.5" stroke="#FF7900" strokeWidth="1.8" />
        {/* Tiny pearl stamp on parcel */}
        <circle cx="10" cy="8.5" r="2.5" fill="#075B9A" />
      </g>
    </svg>
  );
}
